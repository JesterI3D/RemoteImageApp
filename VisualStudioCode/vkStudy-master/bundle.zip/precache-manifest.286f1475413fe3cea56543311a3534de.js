self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dd6b1ac0102abc0682b2b5a01b8b5226",
    "url": "/index.html"
  },
  {
    "revision": "ec9f199f18afb47a1621",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "2d9f92bae49278a575c6",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "ec9f199f18afb47a1621",
    "url": "/static/js/2.682144bb.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.682144bb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2d9f92bae49278a575c6",
    "url": "/static/js/main.4a0fa3ae.chunk.js"
  },
  {
    "revision": "36d3679a8b16e8c714f9",
    "url": "/static/js/runtime-main.f7ec511b.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);